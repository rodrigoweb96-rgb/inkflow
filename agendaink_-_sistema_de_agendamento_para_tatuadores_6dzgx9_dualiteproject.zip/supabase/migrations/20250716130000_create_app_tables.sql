/*
          # Criação das Tabelas da Aplicação (Clients, Professionals, Appointments)
          Este script cria as tabelas principais para o funcionamento do AgendaInk e estabelece as regras de segurança para garantir que cada usuário só possa acessar seus próprios dados.

          ## Query Description: Este script é seguro para ser executado. Ele irá:
          1. Criar a tabela `clients` para armazenar os dados dos clientes.
          2. Criar a tabela `professionals` para os profissionais/tatuadores.
          3. Criar a tabela `appointments` para os agendamentos.
          4. Habilitar a Segurança em Nível de Linha (RLS) para todas as tabelas, isolando os dados por usuário.
          5. Criar políticas de acesso que permitem que os usuários criem, leiam, atualizem e apaguem apenas seus próprios registros.
          Não há risco de perda de dados existentes, pois estas são tabelas novas.
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true (pode ser revertido com DROP TABLE)
          
          ## Structure Details:
          - Tabelas Criadas: `clients`, `professionals`, `appointments`.
          - Colunas Adicionadas: Todas as colunas necessárias para cada tabela, incluindo `user_id` para vincular os dados ao usuário autenticado.
          - Relacionamentos: Chaves estrangeiras entre `appointments` e as tabelas `clients` e `professionals`.
          
          ## Security Implications:
          - RLS Status: Habilitado para todas as novas tabelas.
          - Policy Changes: Sim, políticas de acesso baseadas no `user_id` são criadas para garantir a privacidade dos dados.
          - Auth Requirements: As operações de escrita e leitura exigirão um usuário autenticado.
          
          ## Performance Impact:
          - Indexes: Índices de chave primária e chave estrangeira são criados automaticamente, garantindo bom desempenho para as consultas.
          - Triggers: Nenhum.
          - Estimated Impact: Baixo. A criação de tabelas é uma operação rápida.
          */

-- Tabela de Clientes
CREATE TABLE public.clients (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    name text NOT NULL,
    document text NULL,
    birthdate date NULL,
    phone text NOT NULL,
    address text NULL,
    notes text NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT clients_pkey PRIMARY KEY (id),
    CONSTRAINT clients_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users" ON public.clients FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Tabela de Profissionais
CREATE TABLE public.professionals (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT professionals_pkey PRIMARY KEY (id),
    CONSTRAINT professionals_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users" ON public.professionals FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Tabela de Agendamentos
CREATE TABLE public.appointments (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    professional_id uuid NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    value_total numeric NOT NULL,
    value_deposit numeric NOT NULL,
    value_remaining numeric NOT NULL,
    notes text NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT appointments_pkey PRIMARY KEY (id),
    CONSTRAINT appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE,
    CONSTRAINT appointments_professional_id_fkey FOREIGN KEY (professional_id) REFERENCES public.professionals(id) ON DELETE CASCADE,
    CONSTRAINT appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users" ON public.appointments FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Adiciona comentários para clareza
COMMENT ON TABLE public.clients IS 'Armazena os clientes de cada usuário do sistema.';
COMMENT ON TABLE public.professionals IS 'Armazena os profissionais (tatuadores) de cada usuário.';
COMMENT ON TABLE public.appointments IS 'Armazena os agendamentos, conectando clientes e profissionais.';
