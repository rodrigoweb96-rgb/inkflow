/*
# [User Profile Setup]
This script sets up the `profiles` table to store user data and configures a trigger to automatically create a profile for new users after they sign up. It also enables Row Level Security (RLS) to ensure users can only access their own data.

## Query Description: 
This operation creates a new `profiles` table linked to `auth.users`. It is a non-destructive, structural change. A trigger is added to `auth.users` that automatically populates the `profiles` table upon new user creation. This is a safe operation as it only adds new structures and automation. No existing data is affected.

## Metadata:
- Schema-Category: "Structural"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- **Tables Created:**
  - `public.profiles`
- **Columns Added to `profiles`:**
  - `id` (uuid, FK to auth.users.id)
  - `updated_at` (timestamptz)
  - `username` (text)
  - `full_name` (text)
  - `avatar_url` (text)
- **Functions Created:**
  - `public.handle_new_user()`
- **Triggers Created:**
  - `on_auth_user_created` on `auth.users` table.

## Security Implications:
- RLS Status: Enabled on `public.profiles`.
- Policy Changes: Yes. New policies are created for `SELECT`, `INSERT` and `UPDATE` on `public.profiles` to restrict access to the owner of the record.
- Auth Requirements: Policies use `auth.uid()` to identify the current user.

## Performance Impact:
- Indexes: A primary key index is created on `profiles.id`.
- Triggers: An `AFTER INSERT` trigger is added to `auth.users`. The performance impact is negligible for typical sign-up volumes.
- Estimated Impact: Low.
*/

-- 1. Create a table for public user profiles
create table public.profiles (
  id uuid not null references auth.users on delete cascade,
  updated_at timestamp with time zone,
  username text unique,
  full_name text,
  avatar_url text,
  primary key (id),
  unique(username),
  constraint username_length check (char_length(username) >= 3)
);

-- 2. Set up Row Level Security (RLS)
alter table public.profiles
  enable row level security;

create policy "Public profiles are viewable by everyone." on public.profiles
  for select using (true);

create policy "Users can insert their own profile." on public.profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile." on public.profiles
  for update using (auth.uid() = id);

-- 3. This trigger automatically creates a profile for new users.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  return new;
end;
$$;

-- 4. Create the trigger
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
