export interface Client {
  id: string;
  user_id: string;
  name: string;
  document: string | null;
  birthdate: string | null;
  phone: string;
  address: string | null;
  notes: string | null;
  created_at: string;
}

export interface Professional {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  created_at: string;
}

export interface Appointment {
  id: string;
  user_id: string;
  client_id: string;
  professional_id: string;
  date: string;
  time: string;
  value_total: number;
  value_deposit: number;
  value_remaining: number;
  notes: string | null;
  created_at: string;
}

export interface AppointmentWithDetails extends Omit<Appointment, 'client_id' | 'professional_id'> {
  clients: {
    id: string;
    name: string;
    phone: string;
  } | null;
  professionals: {
    id: string;
    name: string;
  } | null;
}
