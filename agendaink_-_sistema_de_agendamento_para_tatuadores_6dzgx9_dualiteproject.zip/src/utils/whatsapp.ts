import { AppointmentWithDetails } from '../types';

export const sendWhatsAppConfirmation = (appointment: AppointmentWithDetails): void => {
  if (!appointment.clients || !appointment.professionals) {
    console.error("Cannot send WhatsApp confirmation: missing client or professional details.");
    return;
  }

  const message = `
🎨 *Confirmação de Agendamento - AgendaInk*

Olá *${appointment.clients.name}*!

Seu agendamento foi confirmado:

📅 *Data:* ${new Date(appointment.date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}
🕐 *Horário:* ${appointment.time}
👤 *Profissional:* ${appointment.professionals.name}

💰 *Valor Total:* R$ ${appointment.value_total.toFixed(2)}
💵 *Sinal:* R$ ${appointment.value_deposit.toFixed(2)}
💸 *Restante:* R$ ${appointment.value_remaining.toFixed(2)}

${appointment.notes ? `📝 *Observações:* ${appointment.notes}` : ''}

Aguardamos você! 🖤
  `.trim();

  const phoneNumber = appointment.clients.phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/55${phoneNumber}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};
