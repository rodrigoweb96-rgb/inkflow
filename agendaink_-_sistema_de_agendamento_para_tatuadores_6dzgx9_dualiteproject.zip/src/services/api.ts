import { supabase } from '../utils/supabase';
import { Client, Professional, Appointment, AppointmentWithDetails } from '../types';

type ClientInsert = Omit<Client, 'id' | 'user_id' | 'created_at'>;
type ProfessionalInsert = Omit<Professional, 'id' | 'user_id' | 'created_at'>;
type AppointmentInsert = Omit<Appointment, 'id' | 'user_id' | 'created_at'>;

const getUserId = async (): Promise<string> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Usuário não autenticado.");
    return user.id;
}

// --- Clients API ---
export const getClients = async (): Promise<Client[]> => {
  const { data, error } = await supabase.from('clients').select('*').order('name');
  if (error) throw error;
  return data || [];
};

export const addClient = async (client: ClientInsert): Promise<Client> => {
  const userId = await getUserId();
  const { data, error } = await supabase.from('clients').insert({ ...client, user_id: userId }).select().single();
  if (error) throw error;
  return data;
};

export const updateClient = async (id: string, client: Partial<ClientInsert>): Promise<Client> => {
  const { data, error } = await supabase.from('clients').update(client).eq('id', id).select().single();
  if (error) throw error;
  return data;
};

export const deleteClient = async (id: string): Promise<void> => {
  const { error } = await supabase.from('clients').delete().eq('id', id);
  if (error) throw error;
};

// --- Professionals API ---
export const getProfessionals = async (): Promise<Professional[]> => {
  const { data, error } = await supabase.from('professionals').select('*').order('name');
  if (error) throw error;
  return data || [];
};

export const addProfessional = async (professional: ProfessionalInsert): Promise<Professional> => {
  const userId = await getUserId();
  const { data, error } = await supabase.from('professionals').insert({ ...professional, user_id: userId }).select().single();
  if (error) throw error;
  return data;
};

export const updateProfessional = async (id: string, professional: Partial<ProfessionalInsert>): Promise<Professional> => {
  const { data, error } = await supabase.from('professionals').update(professional).eq('id', id).select().single();
  if (error) throw error;
  return data;
};

export const deleteProfessional = async (id: string): Promise<void> => {
  const { error } = await supabase.from('professionals').delete().eq('id', id);
  if (error) throw error;
};

// --- Appointments API ---
export const getAppointmentsWithDetails = async (): Promise<AppointmentWithDetails[]> => {
    const { data, error } = await supabase
        .from('appointments')
        .select(`
            *,
            clients ( id, name, phone ),
            professionals ( id, name )
        `)
        .order('date', { ascending: false });

    if (error) throw error;
    return (data as AppointmentWithDetails[]) || [];
};


export const addAppointment = async (appointment: AppointmentInsert): Promise<AppointmentWithDetails> => {
  const userId = await getUserId();
  const { data, error } = await supabase.from('appointments').insert({ ...appointment, user_id: userId }).select(`
    *,
    clients ( id, name, phone ),
    professionals ( id, name )
  `).single();
  if (error) throw error;
  return data as AppointmentWithDetails;
};

export const updateAppointment = async (id: string, appointment: Partial<AppointmentInsert>): Promise<Appointment> => {
  const { data, error } = await supabase.from('appointments').update(appointment).eq('id', id).select().single();
  if (error) throw error;
  return data;
};

export const deleteAppointment = async (id: string): Promise<void> => {
  const { error } = await supabase.from('appointments').delete().eq('id', id);
  if (error) throw error;
};

export const checkConflict = async (professional_id: string, date: string, time: string, excludeId?: string): Promise<boolean> => {
    let query = supabase
      .from('appointments')
      .select('id', { count: 'exact', head: true })
      .eq('professional_id', professional_id)
      .eq('date', date)
      .eq('time', time);

    if (excludeId) {
      query = query.neq('id', excludeId);
    }

    const { count, error } = await query;
    if (error) throw error;
    return (count || 0) > 0;
};
