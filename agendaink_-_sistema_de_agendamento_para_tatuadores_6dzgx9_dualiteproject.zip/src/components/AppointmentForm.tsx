import React, { useState, useEffect } from 'react';
import { X, Plus, MessageCircle } from 'lucide-react';
import * as api from '../services/api';
import { sendWhatsAppConfirmation } from '../utils/whatsapp';
import { Client, Professional } from '../types';

interface AppointmentFormProps {
  editingId: string | null;
  onClose: () => void;
  onSuccess: () => void;
  initialDate?: string;
}

export const AppointmentForm: React.FC<AppointmentFormProps> = ({ editingId, onClose, onSuccess, initialDate }) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [showNewClientForm, setShowNewClientForm] = useState(false);
  const [conflictError, setConflictError] = useState('');
  const [loading, setLoading] = useState(true);
  
  const [formData, setFormData] = useState({
    client_id: '',
    professional_id: '',
    date: initialDate || new Date().toISOString().split('T')[0],
    time: '',
    value_deposit: '',
    value_remaining: '',
    notes: '',
  });

  const [newClientData, setNewClientData] = useState({
    name: '',
    document: '',
    birthdate: '',
    phone: '',
    address: '',
    notes: '',
  });

  useEffect(() => {
    const loadInitialData = async () => {
        try {
            setLoading(true);
            const [clientsData, professionalsData] = await Promise.all([
                api.getClients(),
                api.getProfessionals()
            ]);
            setClients(clientsData);
            setProfessionals(professionalsData);

            if (editingId) {
                // This part is tricky as we don't have a getAppointmentById
                // For now, we assume we can't edit from this form.
                // A full implementation would need a getAppointmentById function.
            }
        } catch (error) {
            console.error("Failed to load data for appointment form", error);
        } finally {
            setLoading(false);
        }
    };
    loadInitialData();
  }, [editingId]);

  const handleAddNewClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientData.name || !newClientData.phone) {
        alert("Nome e WhatsApp são obrigatórios.");
        return;
    }
    try {
        const newClient = await api.addClient({
            name: newClientData.name,
            document: newClientData.document || null,
            birthdate: newClientData.birthdate || null,
            phone: newClientData.phone,
            address: newClientData.address || null,
            notes: newClientData.notes || null,
        });
        setClients(prev => [...prev, newClient]);
        setFormData({ ...formData, client_id: newClient.id });
        setShowNewClientForm(false);
        setNewClientData({ name: '', document: '', birthdate: '', phone: '', address: '', notes: '' });
    } catch (err: any) {
        alert(`Erro ao adicionar cliente: ${err.message}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setConflictError('');

    const hasConflict = await api.checkConflict(
      formData.professional_id,
      formData.date,
      formData.time,
      editingId || undefined
    );

    if (hasConflict) {
      setConflictError('Já existe um agendamento para este profissional neste horário.');
      return;
    }

    const value_deposit = parseFloat(formData.value_deposit) || 0;
    const value_remaining = parseFloat(formData.value_remaining) || 0;
    const value_total = value_deposit + value_remaining;

    const appointmentData = {
      client_id: formData.client_id,
      professional_id: formData.professional_id,
      date: formData.date,
      time: formData.time,
      value_total,
      value_deposit,
      value_remaining,
      notes: formData.notes || null,
    };

    try {
        if (editingId) {
            // await api.updateAppointment(editingId, appointmentData);
            // Editing logic to be fully implemented if needed
            onSuccess();
        } else {
            const newAppointmentWithDetails = await api.addAppointment(appointmentData);
            sendWhatsAppConfirmation(newAppointmentWithDetails);
            onSuccess();
        }
    } catch (err: any) {
        alert(`Erro ao salvar agendamento: ${err.message}`);
    }
  };

  const value_deposit = parseFloat(formData.value_deposit) || 0;
  const value_remaining = parseFloat(formData.value_remaining) || 0;
  const value_total = value_deposit + value_remaining;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white flex items-center justify-between p-6 border-b z-10">
          <h2 className="text-2xl font-bold text-gray-900">{editingId ? 'Editar Agendamento' : 'Novo Agendamento'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-6 h-6" /></button>
        </div>

        {loading ? <div className="p-6 text-center">Carregando...</div> : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {conflictError && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{conflictError}</div>}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Cliente *</label>
              {!showNewClientForm ? (
                <div className="flex gap-2">
                  <select required value={formData.client_id} onChange={(e) => setFormData({ ...formData, client_id: e.target.value })} className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">Selecione um cliente</option>
                    {clients.map((client) => (<option key={client.id} value={client.id}>{client.name} - {client.phone}</option>))}
                  </select>
                  <button type="button" onClick={() => setShowNewClientForm(true)} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Novo
                  </button>
                </div>
              ) : (
                <div className="border border-gray-300 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium text-gray-900">Cadastrar Novo Cliente</h3>
                    <button type="button" onClick={() => setShowNewClientForm(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input type="text" placeholder="Nome *" required value={newClientData.name} onChange={(e) => setNewClientData({ ...newClientData, name: e.target.value })} className="px-3 py-2 border border-gray-300 rounded-lg" />
                      <input type="tel" placeholder="WhatsApp *" required value={newClientData.phone} onChange={(e) => setNewClientData({ ...newClientData, phone: e.target.value })} className="px-3 py-2 border border-gray-300 rounded-lg" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input type="date" placeholder="Data de Nascimento" value={newClientData.birthdate} onChange={(e) => setNewClientData({ ...newClientData, birthdate: e.target.value })} className="px-3 py-2 border border-gray-300 rounded-lg" />
                    <input type="text" placeholder="RG/CPF" value={newClientData.document} onChange={(e) => setNewClientData({ ...newClientData, document: e.target.value })} className="px-3 py-2 border border-gray-300 rounded-lg" />
                  </div>
                  <input type="text" placeholder="Endereço" value={newClientData.address} onChange={(e) => setNewClientData({ ...newClientData, address: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                  <button type="button" onClick={handleAddNewClient} className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">Adicionar Cliente</button>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Profissional *</label>
              <select required value={formData.professional_id} onChange={(e) => setFormData({ ...formData, professional_id: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">Selecione um profissional</option>
                {professionals.map((professional) => (<option key={professional.id} value={professional.id}>{professional.name}</option>))}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data *</label>
                <input type="date" required value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Horário *</label>
                <input type="time" required value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valor Sinal *</label>
                <input type="number" step="0.01" required value={formData.value_deposit} onChange={(e) => setFormData({ ...formData, value_deposit: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="0.00" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valor Faltante *</label>
                <input type="number" step="0.01" required value={formData.value_remaining} onChange={(e) => setFormData({ ...formData, value_remaining: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="0.00" />
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-gray-700"><strong>Valor Total:</strong> R$ {value_total.toFixed(2)}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea rows={3} value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Informações adicionais sobre o agendamento" />
            </div>

            <div className="sticky bottom-0 bg-white flex justify-end gap-3 pt-4 pb-6 px-6 -mx-6 -mb-6 border-t">
              <button type="button" onClick={onClose} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">Cancelar</button>
              <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2">
                {editingId ? 'Salvar Alterações' : (<><MessageCircle className="w-4 h-4" />Agendar e Enviar WhatsApp</>)}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
