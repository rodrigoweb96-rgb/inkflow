import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, ChevronRight, Plus, DollarSign, TrendingUp, Calendar as CalendarIcon, Users, Clock, Eye, EyeOff } from 'lucide-react';
import * as api from '../services/api';
import { AppointmentWithDetails, Professional } from '../types';
import { AppointmentForm } from './AppointmentForm';

const isSameDay = (dateA: Date, dateB: Date) => {
  if (!dateA || !dateB) return false;
  return dateA.getFullYear() === dateB.getFullYear() &&
         dateA.getMonth() === dateB.getMonth() &&
         dateA.getDate() === dateB.getDate();
};

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType, color: string }> = ({ title, value, icon: Icon, color }) => (
  <div className="bg-white rounded-lg shadow p-5 flex items-center gap-4">
    <div className={`${color} rounded-full p-3`}>
      <Icon className="w-6 h-6 text-white" />
    </div>
    <div>
      <p className="text-sm text-gray-500">{title}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  </div>
);

export const Dashboard: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [appointments, setAppointments] = useState<AppointmentWithDetails[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [professionalFilter, setProfessionalFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dateForNewAppointment, setDateForNewAppointment] = useState<string | null>(null);
  const [showFinancials, setShowFinancials] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [appointmentsData, professionalsData] = await Promise.all([
        api.getAppointmentsWithDetails(),
        api.getProfessionals()
      ]);
      setAppointments(appointmentsData);
      setProfessionals(professionalsData);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleFormSuccess = () => {
    loadData();
    setIsModalOpen(false);
    setDateForNewAppointment(null);
  };

  const handleDayClick = (day: Date) => {
    setDateForNewAppointment(day.toISOString().split('T')[0]);
    setIsModalOpen(true);
  };

  const { calendarGrid, monthName, year } = useMemo(() => {
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysInPrevMonth = new Date(year, month, 0).getDate();

    const grid = [];
    for (let i = firstDayOfMonth; i > 0; i--) {
      grid.push({ day: daysInPrevMonth - i + 1, isCurrentMonth: false });
    }
    for (let i = 1; i <= daysInMonth; i++) {
      grid.push({ day: i, isCurrentMonth: true, date: new Date(year, month, i) });
    }
    const remainingCells = 42 - grid.length;
    for (let i = 1; i <= remainingCells; i++) {
      grid.push({ day: i, isCurrentMonth: false });
    }
    
    return {
      calendarGrid: grid,
      monthName: currentDate.toLocaleDateString('pt-BR', { month: 'long' }),
      year,
    };
  }, [currentDate]);

  const filteredAppointments = useMemo(() => {
      if (professionalFilter === 'all') {
          return appointments;
      }
      return appointments.filter(app => app.professionals?.id === professionalFilter);
  }, [appointments, professionalFilter]);

  const appointmentsByDate = useMemo(() => {
    const map = new Map<string, AppointmentWithDetails[]>();
    filteredAppointments.forEach(app => {
        const dateKey = app.date;
        if (!map.has(dateKey)) {
            map.set(dateKey, []);
        }
        map.get(dateKey)!.push(app);
    });
    map.forEach(dayAppointments => {
        dayAppointments.sort((a, b) => a.time.localeCompare(b.time));
    });
    return map;
  }, [filteredAppointments]);

  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const { stats, todayAppointments, upcomingAppointments } = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const monthAppointments = appointments.filter(app => new Date(app.date) >= firstDayOfMonth);
    
    const totalDeposit = monthAppointments.reduce((sum, app) => sum + app.value_deposit, 0);
    const totalRemaining = monthAppointments.filter(app => new Date(app.date) >= now).reduce((sum, app) => sum + app.value_remaining, 0);
    const totalValue = monthAppointments.reduce((sum, app) => sum + app.value_total, 0);

    const todayApps = appointments
      .filter(app => app.date === todayStr)
      .sort((a, b) => a.time.localeCompare(b.time));

    const upcomingApps = appointments
      .filter(app => new Date(app.date) > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 5);

    return {
      stats: {
        totalValue: formatCurrency(totalValue),
        totalDeposit: formatCurrency(totalDeposit),
        totalRemaining: formatCurrency(totalRemaining),
      },
      todayAppointments: todayApps,
      upcomingAppointments: upcomingApps,
    };
  }, [appointments]);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleTodayClick = () => {
    setCurrentDate(new Date());
  };

  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  if (loading) return <div className="text-center p-8">Carregando agenda...</div>;
  if (error) return <div className="bg-red-100 text-red-700 p-4 rounded-lg">Erro: {error}</div>;

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center justify-between mb-4 gap-4">
          <h2 className="text-xl font-bold text-gray-900 capitalize">{monthName} {year}</h2>
          <div className="flex items-center gap-2">
            <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-gray-100">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-gray-100">
              <ChevronRight className="w-5 h-5" />
            </button>
            <button onClick={handleTodayClick} className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
              Hoje
            </button>
          </div>
        </div>
        <div className="mb-4 flex flex-col sm:flex-row gap-4 justify-between items-center">
            <div className="max-w-xs w-full">
                <label htmlFor="agenda_professional_filter" className="text-sm font-medium text-gray-700">Filtrar por Profissional</label>
                <select 
                  id="agenda_professional_filter"
                  value={professionalFilter}
                  onChange={(e) => setProfessionalFilter(e.target.value)}
                  className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                    <option value="all">Todos</option>
                    {professionals.map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                </select>
            </div>
            <button onClick={() => setShowFinancials(!showFinancials)} className="flex items-center gap-2 text-blue-600 font-medium text-sm self-end">
                {showFinancials ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                {showFinancials ? 'Ocultar Resumo Financeiro' : 'Mostrar Resumo Financeiro'}
            </button>
        </div>

        {showFinancials && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                <StatCard title="Faturamento (Mês)" value={stats.totalValue} icon={TrendingUp} color="bg-green-500" />
                <StatCard title="Sinal Recebido (Mês)" value={stats.totalDeposit} icon={DollarSign} color="bg-blue-500" />
                <StatCard title="Previsão de Entrada" value={stats.totalRemaining} icon={CalendarIcon} color="bg-orange-500" />
            </div>
        )}

        <div className="grid grid-cols-7">
          {weekDays.map(day => (
            <div key={day} className="text-center text-xs font-medium text-gray-500 py-2 border-b">{day}</div>
          ))}
          {calendarGrid.map((dayInfo, index) => {
            if (!dayInfo.isCurrentMonth) {
              return <div key={index} className="border-t border-l border-gray-200 bg-gray-50 min-h-[120px]"></div>;
            }
            
            const day = dayInfo.date!;
            const dateKey = day.toISOString().split('T')[0];
            const dayAppointments = appointmentsByDate.get(dateKey) || [];

            return (
              <div
                key={index}
                className="border-t border-l border-gray-200 p-1.5 min-h-[120px] flex flex-col cursor-pointer hover:bg-sky-50 transition-colors relative group"
                onClick={() => handleDayClick(day)}
              >
                <span className={`text-sm font-medium ${
                  isSameDay(day, new Date()) ? 'bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center' : 'text-gray-700'
                }`}>
                  {day.getDate()}
                </span>
                <div className="mt-1 space-y-1 overflow-y-auto text-[11px]">
                  {dayAppointments.map(app => (
                    <div key={app.id} className="bg-blue-500 text-white rounded px-1.5 py-0.5 truncate" title={`${app.time} - ${app.clients?.name}`}>
                      {app.time.slice(0, 5)} {app.clients?.name}
                    </div>
                  ))}
                </div>
                <button className="absolute top-1 right-1 p-1 bg-white/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-100">
                  <Plus className="w-4 h-4 text-gray-600"/>
                </button>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-800">Clientes do Dia</h2>
          </div>
          {todayAppointments.length > 0 ? (
            <ul className="divide-y divide-gray-200">
              {todayAppointments.map(app => (
                <li key={app.id} className="py-3 flex justify-between items-center">
                  <div>
                    <p className="font-medium text-gray-900">{app.clients?.name}</p>
                    <p className="text-sm text-gray-500">{app.professionals?.name}</p>
                  </div>
                  <span className="text-sm font-semibold text-gray-700 bg-gray-100 px-2 py-1 rounded-md">{app.time}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 text-center py-4">Nenhum cliente agendado para hoje.</p>
          )}
        </div>

        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-800">Próximos Agendamentos</h2>
          </div>
          {upcomingAppointments.length > 0 ? (
            <ul className="divide-y divide-gray-200">
              {upcomingAppointments.map(app => (
                <li key={app.id} className="py-3 flex justify-between items-center">
                  <div>
                    <p className="font-medium text-gray-900">{app.clients?.name}</p>
                    <p className="text-sm text-gray-500">{new Date(app.date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })} às {app.time}</p>
                  </div>
                  <span className="text-sm text-gray-600">{app.professionals?.name}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 text-center py-4">Nenhum agendamento futuro encontrado.</p>
          )}
        </div>
      </div>
      
      {isModalOpen && (
        <AppointmentForm
          editingId={null}
          onClose={() => setIsModalOpen(false)}
          onSuccess={handleFormSuccess}
          initialDate={dateForNewAppointment || undefined}
        />
      )}
    </div>
  );
};
