import React, { useState, useEffect, useMemo } from 'react';
import { DollarSign, TrendingUp, Calendar } from 'lucide-react';
import * as api from '../services/api';
import { AppointmentWithDetails, Professional } from '../types';

type FilterPeriod = 'this_month' | 'next_month' | 'all';

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType }> = ({ title, value, icon: Icon }) => (
  <div className="bg-white rounded-lg shadow p-5 flex items-center gap-4">
    <div className="bg-blue-100 text-blue-600 rounded-full p-3">
      <Icon className="w-6 h-6" />
    </div>
    <div>
      <p className="text-sm text-gray-500">{title}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  </div>
);

export const Financial: React.FC = () => {
  const [appointments, setAppointments] = useState<AppointmentWithDetails[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [periodFilter, setPeriodFilter] = useState<FilterPeriod>('this_month');
  const [professionalFilter, setProfessionalFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
        try {
            setLoading(true);
            setError(null);
            const [appointmentsData, professionalsData] = await Promise.all([
                api.getAppointmentsWithDetails(),
                api.getProfessionals()
            ]);
            setAppointments(appointmentsData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
            setProfessionals(professionalsData);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };
    loadData();
  }, []);

  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const filteredAppointments = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    return appointments.filter(app => {
      // Professional filter
      if (professionalFilter !== 'all' && app.professionals?.id !== professionalFilter) {
        return false;
      }

      // Period filter
      if (periodFilter === 'all') {
        return true;
      }

      const appDate = new Date(app.date);
      const appYear = appDate.getUTCFullYear();
      const appMonth = appDate.getUTCMonth();

      if (periodFilter === 'this_month') {
        return appYear === currentYear && appMonth === currentMonth;
      }
      if (periodFilter === 'next_month') {
        const nextMonthDate = new Date(currentYear, currentMonth + 1, 1);
        return appYear === nextMonthDate.getFullYear() && appMonth === nextMonthDate.getMonth();
      }
      return false;
    });
  }, [appointments, periodFilter, professionalFilter]);

  const stats = useMemo(() => {
    const totalDeposit = filteredAppointments.reduce((sum, app) => sum + app.value_deposit, 0);
    const totalRemaining = filteredAppointments.reduce((sum, app) => sum + app.value_remaining, 0);
    const totalValue = filteredAppointments.reduce((sum, app) => sum + app.value_total, 0);

    return {
      totalDeposit: formatCurrency(totalDeposit),
      totalRemaining: formatCurrency(totalRemaining),
      totalValue: formatCurrency(totalValue),
    };
  }, [filteredAppointments]);

  const periodFilterOptions: { id: FilterPeriod; label: string }[] = [
    { id: 'this_month', label: 'Este Mês' },
    { id: 'next_month', label: 'Próximo Mês' },
    { id: 'all', label: 'Todo o Período' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Financeiro</h1>
      
      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-1">
            <label className="text-sm font-medium text-gray-700">Período</label>
            <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1 mt-1">
              {periodFilterOptions.map(option => (
                <button
                  key={option.id}
                  onClick={() => setPeriodFilter(option.id)}
                  className={`flex-1 px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    periodFilter === option.id
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
        </div>
        <div className="flex-1">
            <label htmlFor="professional_filter" className="text-sm font-medium text-gray-700">Profissional</label>
            <select 
              id="professional_filter"
              value={professionalFilter}
              onChange={(e) => setProfessionalFilter(e.target.value)}
              className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
                <option value="all">Todos os Profissionais</option>
                {professionals.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                ))}
            </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard title="Total Faturado" value={stats.totalValue} icon={TrendingUp} />
        <StatCard title="Sinal Recebido" value={stats.totalDeposit} icon={DollarSign} />
        <StatCard title="Valor Restante" value={stats.totalRemaining} icon={Calendar} />
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <h2 className="text-xl font-semibold text-gray-800 p-6 border-b">
          Detalhes dos Agendamentos
        </h2>
        {loading && <p className="text-center p-8 text-gray-500">Carregando detalhes...</p>}
        {error && <p className="text-center p-8 text-red-500">Erro: {error}</p>}
        {!loading && !error && (
            <>
                {filteredAppointments.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Nenhum agendamento encontrado para este período.</p>
                ) : (
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">Profissional</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sinal</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Restante</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredAppointments.map((app) => (
                        <tr key={app.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{new Date(app.date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{app.clients?.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 hidden sm:table-cell">{app.professionals?.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(app.value_total)}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">{formatCurrency(app.value_deposit)}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-medium">{formatCurrency(app.value_remaining)}</td>
                        </tr>
                        ))}
                    </tbody>
                    </table>
                </div>
                )}
            </>
        )}
      </div>
    </div>
  );
};
