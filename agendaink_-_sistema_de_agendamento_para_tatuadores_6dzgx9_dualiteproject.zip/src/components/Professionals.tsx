import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, X } from 'lucide-react';
import * as api from '../services/api';
import { Professional } from '../types';

export const Professionals: React.FC = () => {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProfessional, setEditingProfessional] = useState<Professional | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '' });

  useEffect(() => {
    loadProfessionals();
  }, []);

  const loadProfessionals = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getProfessionals();
      setProfessionals(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingProfessional) {
        await api.updateProfessional(editingProfessional.id, formData);
      } else {
        await api.addProfessional(formData);
      }
      await loadProfessionals();
      closeModal();
    } catch (err: any) {
      alert(`Erro ao salvar profissional: ${err.message}`);
    }
  };

  const handleEdit = (professional: Professional) => {
    setEditingProfessional(professional);
    setFormData({ name: professional.name, phone: professional.phone });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este profissional?')) {
      try {
        await api.deleteProfessional(id);
        await loadProfessionals();
      } catch (err: any) {
        alert(`Erro ao excluir profissional: ${err.message}`);
      }
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingProfessional(null);
    setFormData({ name: '', phone: '' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Profissionais</h1>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-5 h-5" />
          Novo Profissional
        </button>
      </div>
      
      {loading && <p className="text-center text-gray-500">Carregando profissionais...</p>}
      {error && <p className="text-center text-red-500">Erro: {error}</p>}

      {!loading && !error && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {professionals.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhum profissional cadastrado</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
              {professionals.map((professional) => (
                <div key={professional.id} className="bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900">{professional.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{professional.phone}</p>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleEdit(professional)} className="text-blue-600 hover:text-blue-900"><Edit2 className="w-5 h-5" /></button>
                      <button onClick={() => handleDelete(professional.id)} className="text-red-600 hover:text-red-900"><Trash2 className="w-5 h-5" /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold text-gray-900">{editingProfessional ? 'Editar Profissional' : 'Novo Profissional'}</h2>
              <button onClick={closeModal} className="text-gray-400 hover:text-gray-600"><X className="w-6 h-6" /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
                <input type="text" required value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp *</label>
                <input type="tel" required placeholder="(00) 00000-0000" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">{editingProfessional ? 'Salvar Alterações' : 'Cadastrar Profissional'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
